# YEAKUB FF TOURNAMENT — Starter App

This is a mobile-friendly installable web app starter. It includes two free tournament cards, a coming-soon paid tournament card, a registration preview form, and a results placeholder.

Important: This is not a compiled Android APK. It has no real accounts, admin authentication, server-side registration storage, room credential management, payment processing, or live results. Do not collect real player information or money until a secure backend and compliance checks are completed.

## Publish with GitHub Pages
1. Upload `index.html`, `manifest.json`, and `sw.js` to the repository root.
2. Open repository Settings → Pages.
3. Choose deploy from a branch; branch `main`, folder `/(root)`, then Save.
4. Wait for GitHub Pages to show the public website URL.

## Install on Android
Open the published HTTPS site in Chrome → menu (⋮) → “Install app” or “Add to Home screen” → confirm. This creates an app-like shortcut, not an APK.

Paid-entry tournaments and cash prizes may be subject to local laws, game publisher rules, and platform policies.
